# Dynamic red-center-x runtime plan

## Goal
Use red detection only to estimate `x_center` on the homography-transformed image.
Do not use blob center-y.

Final crop should be built from:
- anchor `a`
- width `roi_w`
- height `roi_h`
- detected `x_center`

## Proposed runtime parameters
- `red_band_y0`
- `red_band_y1`
- `red_search_x0`
- `red_search_x1`
- `roi_anchor_y`
- `roi_width`
- `roi_height`
- `red_min_area`
- `red_max_area`
- `red_morph_k`
- `red_center_alpha`
- `red_miss_tolerance`
- `red_fallback_mode=center|hold_last|reject`

## Proposed algorithm
1. apply saved warp
2. crop search band `[x0:x1, y0:y1]`
3. HSV threshold red
4. open/close morphology
5. find best contour
6. compute contour center-x only
7. smooth / validate x
8. build final ROI rect from `(x_center, roi_anchor_y, roi_width, roi_height)`
9. clamp ROI to image bounds
10. crop image ROI and pass downstream

## Why keep it separate from current runtime
Current runtime uses fixed saved ROIs and a red-ratio metric.
That is still useful as a baseline.

Keep both paths:
- fixed runtime
- dynamic red-x runtime

That lets you compare stability, latency, and model accuracy directly.
