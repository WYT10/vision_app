# vision_app compact operator pack

This pack keeps the current `probe / calibrate / deploy` architecture, but makes the surface a bit tighter for day-to-day use.

## What changed

- `probe` now exposes focused tasks:
  - `list` — camera mode discovery
  - `live` — preview only
  - `snap` — capture one frame to disk
  - `bench` — timed FPS test with optional markdown report
- `--headless` alias added for `--ui 0`
- project layout cleaned to the more normal shape:
  - `src/`
  - `cmake/`
  - `tools/`
  - `docs/`
- function inventory included in `docs/FUNCTIONS.md`
- example configs included for common workflows

## What is still intentionally unchanged

This pack does **not** yet replace the fixed saved `red_roi` / `image_roi` runtime with the new dynamic red-center-x crop logic.
That should be added as a second runtime path, not patched into the old one blindly.

Recommended future split:

- `fixed_roi_runtime`
- `dynamic_red_x_runtime`

That keeps baseline and experimental behavior separable.

---

## Build on Raspberry Pi

```bash
export CMAKE_PREFIX_PATH=/home/pi/ncnn/build/install:$CMAKE_PREFIX_PATH

cd ~/Desktop/vision_app
rm -rf build
mkdir -p build
cd build
cmake ..
make -j$(nproc)
```

---

## Command model

### 1) Probe

#### List modes

```bash
./vision_app --mode probe --probe-task list --device /dev/video0
```

#### Live preview

```bash
./vision_app \
  --mode probe \
  --probe-task live \
  --device /dev/video0 \
  --width 160 --height 120 --fourcc MJPG --fps 120
```

#### Snap one frame

```bash
./vision_app \
  --mode probe \
  --probe-task snap \
  --device /dev/video0 \
  --width 160 --height 120 --fourcc MJPG --fps 120 \
  --snap-path ../captures/probe.jpg
```

#### Headless benchmark + report

```bash
./vision_app \
  --mode probe \
  --probe-task bench \
  --device /dev/video0 \
  --width 160 --height 120 --fourcc MJPG --fps 120 \
  --headless \
  --duration 10 \
  --save-report ../report/probe_bench.md
```

### 2) Calibrate

```bash
./vision_app \
  --mode calibrate \
  --device /dev/video0 \
  --width 160 --height 120 --fourcc MJPG --fps 120 \
  --warp-width 384 --warp-height 384 \
  --target-tag-px 128 \
  --tag-family auto --target-id 0 \
  --save-warp ../report/warp_package.yml.gz \
  --save-rois ../report/rois.yml
```

### 3) Deploy

```bash
./vision_app \
  --mode deploy \
  --device /dev/video0 \
  --width 160 --height 120 --fourcc MJPG --fps 120 \
  --load-warp ../report/warp_package.yml.gz \
  --load-rois ../report/rois.yml \
  --model-enable 1 \
  --model-backend ncnn \
  --model-ncnn-param-path ../models/model.ncnn.param \
  --model-ncnn-bin-path ../models/model.ncnn.bin \
  --model-labels-path ../models/labels.txt \
  --model-input-width 128 --model-input-height 128 \
  --model-preprocess crop \
  --model-threads 4 \
  --model-stride 1 \
  --model-max-hz 5.0
```

---

## Example configs

Use short commands by putting the stable stuff in config files.

### Probe bench

```bash
./vision_app --config configs/probe_bench.conf --mode probe --probe-task bench
```

### Calibrate

```bash
./vision_app --config configs/pi5_fast.conf --mode calibrate
```

### Deploy

```bash
./vision_app --config configs/pi5_fast.conf --mode deploy
```

---

## Operator optimizations

These are the best near-term wins.

### Compactness

- use config files for stable camera/model settings
- reserve CLI overrides for only what changes in a session
- keep one known-good `pi5_fast.conf`

### Runtime stability

- keep calibration and deploy on the same camera mode
- keep `latest_only=1` and low `buffer_size`
- use `run_red / run_image_roi / run_model` separately when isolating faults

### Experiment hygiene

- compare `fixed_roi_runtime` vs future `dynamic_red_x_runtime` under the same saved warp
- log benchmark reports whenever you change camera mode, backend, or preprocessing

### Next code changes worth doing

1. add dynamic red-center-x crop as a separate runtime path
2. add red mask / contour / center-line debug windows in calibrate
3. add deploy benchmark reports with averaged warp / roi / model timing
4. split inline app-flow code into dedicated `mode_probe.cpp`, `mode_calibrate.cpp`, `mode_deploy.cpp`

---

## File map

- `src/main.cpp` — CLI entrypoint
- `src/camera.hpp` — probe / capture helpers
- `src/calibrate.hpp` — tag detection, warp package, ROI geometry
- `src/deploy.hpp` — calibrate and deploy app loops
- `src/roi_helper.cpp` — runtime ROI extraction
- `src/model.cpp` / `src/model.hpp` — classifier runtime facade
- `docs/FUNCTIONS.md` — function inventory
- `tools/` — dataset + training + export helpers
