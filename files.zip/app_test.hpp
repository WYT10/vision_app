#pragma once

#include "app_config.hpp"

/**
 * @file app_test.hpp
 * @brief Hardware profiler — measures raw camera latency and physical FPS.
 *
 * This mode does zero image processing. Its only job is to tell you exactly
 * how fast the camera hardware delivers frames and what the per-frame latency
 * is, so you can validate timing budgets before deploying the full pipeline.
 */

/**
 * @brief Run the hardware profiler.
 *
 * Loops indefinitely (Ctrl-C or 'q' to quit).
 *
 * @param config  Full AppConfig — only the camera sub-struct is used.
 * @param no_ui   If false: overlay stats on a live preview window.
 *                If true:  print stats to stdout using \\r line-overwrite.
 */
void run_test_mode(const AppConfig& config, bool no_ui);
