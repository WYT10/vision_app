#include "app_camera.hpp"

#include <iostream>
#include <opencv2/videoio.hpp>

/**
 * @file app_camera.cpp
 * @brief Hardware wrapper implementation.
 *
 * Key guarantees enforced here:
 *  1. V4L2 backend is always used — never the default auto-detect.
 *  2. Buffer size is locked to 1 frame to prevent the pipeline from reading
 *     stale queued frames (the "lag" problem on USB webcams).
 *  3. Auto-exposure is forced off and a fixed exposure is set so that
 *     lighting conditions on the track do not cause mid-race flickering.
 */

// ---------------------------------------------------------------------------
// open
// ---------------------------------------------------------------------------

bool AppCamera::open(const CameraConfig& cfg)
{
    // Force V4L2 backend — never rely on OpenCV's auto-detection.
    cap_.open(cfg.camera_id, cv::CAP_V4L2);

    if (!cap_.isOpened()) {
        std::cerr << "[AppCamera] ERROR: Cannot open camera id="
                  << cfg.camera_id << " with CAP_V4L2 backend.\n";
        return false;
    }

    // Resolution
    cap_.set(cv::CAP_PROP_FRAME_WIDTH,  cfg.width);
    cap_.set(cv::CAP_PROP_FRAME_HEIGHT, cfg.height);

    // Frame rate
    cap_.set(cv::CAP_PROP_FPS, cfg.fps);

    // Anti-lag lock: keep only the most recent frame in the driver queue.
    // Without this, cv::VideoCapture can buffer multiple frames and read() will
    // return frames that are already several milliseconds old.
    cap_.set(cv::CAP_PROP_BUFFERSIZE, 1);

    // Auto-exposure kill-switch.
    // V4L2 mode 1 = manual exposure.
    // (Mode 3 = aperture-priority auto, which is the default on most webcams.)
    cap_.set(cv::CAP_PROP_AUTO_EXPOSURE, 1);

    // Fixed exposure value (in device-specific units — tune for your sensor).
    // A value of 100 is a safe starting point for most USB webcams under
    // typical indoor/track lighting conditions.
    cap_.set(cv::CAP_PROP_EXPOSURE, 100);

    // Verify the camera came up at the requested resolution (log only).
    double actual_w = cap_.get(cv::CAP_PROP_FRAME_WIDTH);
    double actual_h = cap_.get(cv::CAP_PROP_FRAME_HEIGHT);
    double actual_fps = cap_.get(cv::CAP_PROP_FPS);

    std::cout << "[AppCamera] Opened camera id=" << cfg.camera_id
              << "  resolution=" << actual_w << "x" << actual_h
              << "  fps=" << actual_fps << "\n";

    if (static_cast<int>(actual_w) != cfg.width ||
        static_cast<int>(actual_h) != cfg.height) {
        std::cerr << "[AppCamera] WARNING: Requested " << cfg.width << "x" << cfg.height
                  << " but got " << actual_w << "x" << actual_h
                  << ". Continuing — check V4L2 supported formats.\n";
    }

    return true;
}

// ---------------------------------------------------------------------------
// read
// ---------------------------------------------------------------------------

bool AppCamera::read(cv::Mat& frame)
{
    return cap_.read(frame);
}

// ---------------------------------------------------------------------------
// release / isOpened
// ---------------------------------------------------------------------------

void AppCamera::release()
{
    cap_.release();
}

bool AppCamera::isOpened() const
{
    return cap_.isOpened();
}

// ---------------------------------------------------------------------------
// Destructor
// ---------------------------------------------------------------------------

AppCamera::~AppCamera()
{
    release();
}
