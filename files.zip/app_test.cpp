#include "app_test.hpp"
#include "app_camera.hpp"

#include <chrono>
#include <iostream>
#include <iomanip>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

/**
 * @file app_test.cpp
 * @brief Hardware profiler implementation.
 *
 * Timing strategy:
 *  - Per-frame latency:  std::chrono::high_resolution_clock bracketing cam.read().
 *  - Physical FPS:       Rolling 1-second window (frames grabbed / elapsed seconds).
 *
 * The rolling window resets every time it exceeds 1.0 seconds so the displayed
 * FPS reflects what the hardware is actually delivering right now, not a
 * cumulative average from startup.
 */

using Clock     = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::time_point<Clock>;

// ---------------------------------------------------------------------------
// run_test_mode
// ---------------------------------------------------------------------------

void run_test_mode(const AppConfig& config, bool no_ui)
{
    AppCamera cam;
    if (!cam.open(config.camera)) {
        std::cerr << "[TestMode] ERROR: Failed to open camera. Aborting.\n";
        return;
    }

    cv::Mat frame;

    // Rolling FPS window
    int     frame_count     = 0;
    double  rolling_fps     = 0.0;
    TimePoint window_start  = Clock::now();

    // Per-frame latency
    double  latency_ms      = 0.0;

    std::cout << "[TestMode] Running. Press 'q' (UI mode) or Ctrl-C (headless) to quit.\n";

    while (true) {
        // --- Per-frame latency measurement ---
        TimePoint t0 = Clock::now();
        bool ok = cam.read(frame);
        TimePoint t1 = Clock::now();

        if (!ok || frame.empty()) {
            std::cerr << "[TestMode] WARNING: Empty frame received.\n";
            continue;
        }

        latency_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        // --- Rolling FPS calculation ---
        ++frame_count;
        double elapsed_s = std::chrono::duration<double>(t1 - window_start).count();
        if (elapsed_s >= 1.0) {
            rolling_fps  = static_cast<double>(frame_count) / elapsed_s;
            frame_count  = 0;
            window_start = t1;
        }

        // --- Output ---
        if (!no_ui) {
            // Build overlay string
            std::string fps_text     = "FPS: " + std::to_string(static_cast<int>(rolling_fps));
            std::string latency_text = "Latency: " + std::to_string(latency_ms).substr(0, 5) + " ms";

            cv::putText(frame, fps_text,
                        cv::Point(20, 40),
                        cv::FONT_HERSHEY_SIMPLEX,
                        1.2,
                        cv::Scalar(0, 255, 0),
                        2,
                        cv::LINE_AA);

            cv::putText(frame, latency_text,
                        cv::Point(20, 80),
                        cv::FONT_HERSHEY_SIMPLEX,
                        1.2,
                        cv::Scalar(0, 255, 0),
                        2,
                        cv::LINE_AA);

            cv::imshow("Camera Test", frame);

            // 'q' or ESC to quit
            int key = cv::waitKey(1);
            if (key == 'q' || key == 27) {
                break;
            }
        } else {
            // Headless: overwrite the same terminal line
            std::cout << std::fixed << std::setprecision(1)
                      << "\r[TestMode]  FPS: " << std::setw(6) << rolling_fps
                      << "  |  Latency: " << std::setw(7) << latency_ms << " ms   "
                      << std::flush;
        }
    }

    // Cleanup
    cam.release();
    if (!no_ui) {
        cv::destroyAllWindows();
    } else {
        // Newline so the next shell prompt is on its own line
        std::cout << "\n[TestMode] Done.\n";
    }
}
