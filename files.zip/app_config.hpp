#pragma once

#include <string>
#include <opencv2/core.hpp>

/**
 * @file app_config.hpp
 * @brief Global state manager and configuration struct for the vision pipeline.
 *
 * This is the single source of truth for all runtime parameters. It is loaded
 * once at startup from config.yaml and passed by const-ref to all mode functions.
 * The calibration mode is the only consumer that mutates this struct.
 */

// ---------------------------------------------------------------------------
// Sub-structs (logical grouping for clarity)
// ---------------------------------------------------------------------------

struct CameraConfig {
    int camera_id = 0;
    int width     = 1280;
    int height    = 720;
    int fps       = 60;
};

struct GeometryConfig {
    cv::Mat homography;   ///< 3x3 perspective homography matrix H' (with translation baked in)
    int warp_width  = 0;
    int warp_height = 0;
};

struct RoiConfig {
    /// Normalized [0.0, 1.0] ROI for the red finish line detector
    cv::Rect2f red_line_roi = {0.0f, 0.0f, 1.0f, 0.1f};
    /// Normalized [0.0, 1.0] ROI fed into the YOLO object detector
    cv::Rect2f yolo_roi     = {0.0f, 0.0f, 1.0f, 1.0f};
};

struct HsvConfig {
    int h_min = 0;
    int s_min = 0;
    int v_min = 0;
    int h_max = 179;
    int s_max = 255;
    int v_max = 255;
};

// ---------------------------------------------------------------------------
// Top-level config struct
// ---------------------------------------------------------------------------

struct AppConfig {
    CameraConfig   camera;
    GeometryConfig geometry;
    RoiConfig      roi;
    HsvConfig      hsv;

    /**
     * @brief Load configuration from a YAML file written by cv::FileStorage.
     * @param path  Filesystem path to config.yaml.
     * @return true on success, false if the file cannot be opened or is malformed.
     */
    bool load(const std::string& path);

    /**
     * @brief Persist the current configuration to a YAML file via cv::FileStorage.
     * @param path  Filesystem path to write (will overwrite if it exists).
     * @return true on success, false on I/O error.
     */
    bool save(const std::string& path) const;
};
