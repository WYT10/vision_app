#include "app_deploy.hpp"
#include "app_camera.hpp"

#include <iostream>
#include <stdexcept>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

/**
 * @file app_deploy.cpp
 * @brief High-performance runtime implementation.
 *
 * Pre-computation strategy (startup, runs ONCE):
 * ─────────────────────────────────────────────
 *   1. Invert H' to get H_inv.
 *   2. For each pixel (px, py) in the ROI bounding box in warp-space:
 *        - Map (px, py) through H_inv → (src_x, src_y) in camera-space.
 *        - Store in map_x / map_y float matrices.
 *   3. Convert float maps to CV_16SC2 via cv::convertMaps.
 *
 * Main loop (runs at camera FPS):
 * ────────────────────────────────
 *   cam.read → cv::remap red-line crop → cvtColor → inRange → countNonZero
 *   → (if triggered) cv::remap YOLO crop → TODO: ONNX/NCNN inference
 *
 * No full-frame warpPerspective. No dynamic memory allocation in the loop.
 */

// ---------------------------------------------------------------------------
// Internal helper: build remap maps for a normalized ROI
// ---------------------------------------------------------------------------

/**
 * @brief Build float remap maps for a normalized ROI using the inverse homography.
 *
 * @param H_inv      Inverse of the calibrated homography H'.
 * @param norm_roi   Normalized ROI in warp-space [0,1].
 * @param warp_w     Full warp output width (pixels).
 * @param warp_h     Full warp output height (pixels).
 * @param map_x_f    [out] float map for x (column) coordinates in camera-space.
 * @param map_y_f    [out] float map for y (row) coordinates in camera-space.
 * @param px_roi     [out] Absolute pixel rect of the ROI in warp-space.
 */
static void buildRemapMaps(
    const cv::Mat&      H_inv,
    const cv::Rect2f&   norm_roi,
    int                 warp_w,
    int                 warp_h,
    cv::Mat&            map_x_f,
    cv::Mat&            map_y_f,
    cv::Rect&           px_roi)
{
    // Convert normalized ROI to absolute pixels in warp-space
    px_roi = cv::Rect(
        static_cast<int>(norm_roi.x      * warp_w),
        static_cast<int>(norm_roi.y      * warp_h),
        static_cast<int>(norm_roi.width  * warp_w),
        static_cast<int>(norm_roi.height * warp_h)
    );

    map_x_f.create(px_roi.height, px_roi.width, CV_32F);
    map_y_f.create(px_roi.height, px_roi.width, CV_32F);

    // H_inv must be 64F for perspectiveTransform
    cv::Mat H_inv_64;
    H_inv.convertTo(H_inv_64, CV_64F);

    // Iterate over every output pixel in the ROI and compute its camera-space source
    std::vector<cv::Point2f> pts_warp, pts_cam;
    pts_warp.reserve(px_roi.width * px_roi.height);

    for (int row = 0; row < px_roi.height; ++row) {
        for (int col = 0; col < px_roi.width; ++col) {
            pts_warp.emplace_back(
                static_cast<float>(px_roi.x + col),
                static_cast<float>(px_roi.y + row)
            );
        }
    }

    cv::perspectiveTransform(pts_warp, pts_cam, H_inv_64);

    // Unpack into separate x / y maps
    int idx = 0;
    for (int row = 0; row < px_roi.height; ++row) {
        float* row_x = map_x_f.ptr<float>(row);
        float* row_y = map_y_f.ptr<float>(row);
        for (int col = 0; col < px_roi.width; ++col, ++idx) {
            row_x[col] = pts_cam[idx].x;
            row_y[col] = pts_cam[idx].y;
        }
    }
}

// ---------------------------------------------------------------------------
// run_deploy_mode
// ---------------------------------------------------------------------------

void run_deploy_mode(const AppConfig& config, bool no_ui)
{
    // -----------------------------------------------------------------------
    // Validate config
    // -----------------------------------------------------------------------
    if (config.geometry.homography.empty()) {
        std::cerr << "[Deploy] ERROR: Homography matrix is empty. Run --calib first.\n";
        return;
    }
    if (config.geometry.warp_width <= 0 || config.geometry.warp_height <= 0) {
        std::cerr << "[Deploy] ERROR: Invalid warp dimensions. Run --calib first.\n";
        return;
    }

    const int warp_w = config.geometry.warp_width;
    const int warp_h = config.geometry.warp_height;

    // -----------------------------------------------------------------------
    // PRE-COMPUTATION: Inverse homography
    // -----------------------------------------------------------------------
    cv::Mat H_64;
    config.geometry.homography.convertTo(H_64, CV_64F);
    cv::Mat H_inv = H_64.inv();

    std::cout << "[Deploy] Pre-computing remap maps...\n";

    // -----------------------------------------------------------------------
    // PRE-COMPUTATION: Red line remap maps
    // -----------------------------------------------------------------------
    cv::Mat rl_map_x_f, rl_map_y_f;
    cv::Rect rl_px_roi;
    buildRemapMaps(H_inv, config.roi.red_line_roi, warp_w, warp_h,
                   rl_map_x_f, rl_map_y_f, rl_px_roi);

    // Convert to CV_16SC2 for ARM NEON acceleration
    cv::Mat rl_map_x_16, rl_map_y_16;
    cv::convertMaps(rl_map_x_f, rl_map_y_f,
                    rl_map_x_16, rl_map_y_16,
                    CV_16SC2);

    std::cout << "[Deploy] Red line remap map: " << rl_px_roi.width
              << "x" << rl_px_roi.height << " px\n";

    // -----------------------------------------------------------------------
    // PRE-COMPUTATION: YOLO remap maps
    // -----------------------------------------------------------------------
    cv::Mat yolo_map_x_f, yolo_map_y_f;
    cv::Rect yolo_px_roi;
    buildRemapMaps(H_inv, config.roi.yolo_roi, warp_w, warp_h,
                   yolo_map_x_f, yolo_map_y_f, yolo_px_roi);

    cv::Mat yolo_map_x_16, yolo_map_y_16;
    cv::convertMaps(yolo_map_x_f, yolo_map_y_f,
                    yolo_map_x_16, yolo_map_y_16,
                    CV_16SC2);

    std::cout << "[Deploy] YOLO remap map:     " << yolo_px_roi.width
              << "x" << yolo_px_roi.height << " px\n";

    // -----------------------------------------------------------------------
    // PRE-COMPUTATION: HSV threshold scalars (avoid re-constructing every frame)
    // -----------------------------------------------------------------------
    const cv::Scalar hsv_low (config.hsv.h_min, config.hsv.s_min, config.hsv.v_min);
    const cv::Scalar hsv_high(config.hsv.h_max, config.hsv.s_max, config.hsv.v_max);

    // Red pixel count threshold to trigger YOLO gate (tune per track)
    // Default: 0.5% of the red-line ROI area
    const int red_pixel_threshold = std::max(1,
        static_cast<int>(rl_px_roi.width * rl_px_roi.height * 0.005));

    std::cout << "[Deploy] Red pixel threshold: " << red_pixel_threshold << " px\n";
    std::cout << "[Deploy] Entering main loop. Press 'q' to quit.\n";

    // -----------------------------------------------------------------------
    // Open camera
    // -----------------------------------------------------------------------
    AppCamera cam;
    if (!cam.open(config.camera)) {
        std::cerr << "[Deploy] ERROR: Failed to open camera. Aborting.\n";
        return;
    }

    // Pre-allocate output matrices (no per-loop heap allocation)
    cv::Mat frame, red_line_crop, yolo_crop, hsv_crop, mask;

    // -----------------------------------------------------------------------
    // MAIN LOOP
    // -----------------------------------------------------------------------
    while (true) {
        // Step 1: grab latest frame from camera
        if (!cam.read(frame) || frame.empty()) {
            std::cerr << "[Deploy] WARNING: Empty frame.\n";
            continue;
        }

        // Step 2: FAST GATE — remap only the red-line ROI from camera-space
        // directly into the corrected crop. No full warpPerspective.
        cv::remap(frame,
                  red_line_crop,
                  rl_map_x_16,
                  rl_map_y_16,
                  cv::INTER_LINEAR);

        // Step 3: Convert red-line crop to HSV and threshold
        cv::cvtColor(red_line_crop, hsv_crop, cv::COLOR_BGR2HSV);
        cv::inRange(hsv_crop, hsv_low, hsv_high, mask);

        // Step 4: Count activated (red) pixels
        int red_pixels = cv::countNonZero(mask);

        // Step 5: HEAVY GATE — only invoke YOLO crop when red line is detected
        if (red_pixels > red_pixel_threshold) {
            // Step 5a: remap only the YOLO ROI
            cv::remap(frame,
                      yolo_crop,
                      yolo_map_x_16,
                      yolo_map_y_16,
                      cv::INTER_LINEAR);

            // TODO: Pass yolo_crop to ONNX/NCNN inference runtime
            // e.g.: yolo_model.run(yolo_crop, detections);

            if (!no_ui) {
                cv::imshow("YOLO INPUT", yolo_crop);
            }
        }

        // Optional UI: show red line mask
        if (!no_ui) {
            cv::imshow("Red Line Mask", mask);

            int key = cv::waitKey(1);
            if (key == 'q' || key == 27) {
                break;
            }
        }
    }

    // -----------------------------------------------------------------------
    // Cleanup
    // -----------------------------------------------------------------------
    cam.release();
    if (!no_ui) {
        cv::destroyAllWindows();
    }
    std::cout << "\n[Deploy] Exited.\n";
}
