#include "app_calib.hpp"
#include "app_camera.hpp"

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/aruco.hpp>

/**
 * @file app_calib.cpp
 * @brief Spatial calibration engine — full state machine implementation.
 *
 * Adaptive H-Matrix strategy:
 *   Raw homography H maps from camera-space to an arbitrary perspective plane.
 *   We project the original image corners through H to find the actual bounding
 *   box of the warped image, then prepend a translation matrix T so that the
 *   output always starts at (0,0). The final H' = T * H.
 *
 * This means warp_width and warp_height will differ from the camera resolution
 * and will correctly contain the entire warped track without cropping.
 */

// ---------------------------------------------------------------------------
// Internal helper: compute adaptive H' from 4 src/dst point pairs
// ---------------------------------------------------------------------------

static bool computeAdaptiveHomography(
    const std::vector<cv::Point2f>& src_pts,
    const std::vector<cv::Point2f>& dst_pts,
    int img_width,
    int img_height,
    cv::Mat& H_out,
    int& warp_w_out,
    int& warp_h_out)
{
    if (src_pts.size() < 4 || dst_pts.size() < 4) {
        std::cerr << "[Calib] Not enough points for homography.\n";
        return false;
    }

    // Step 1: raw homography
    cv::Mat H = cv::findHomography(src_pts, dst_pts, 0);
    if (H.empty()) {
        std::cerr << "[Calib] findHomography failed.\n";
        return false;
    }

    // Step 2: project the 4 image corners through H
    std::vector<cv::Point2f> corners_in = {
        {0.0f,                   0.0f},
        {static_cast<float>(img_width), 0.0f},
        {static_cast<float>(img_width), static_cast<float>(img_height)},
        {0.0f,                   static_cast<float>(img_height)}
    };
    std::vector<cv::Point2f> corners_out;
    cv::perspectiveTransform(corners_in, corners_out, H);

    // Step 3: bounding box of transformed corners
    float min_x = corners_out[0].x, max_x = corners_out[0].x;
    float min_y = corners_out[0].y, max_y = corners_out[0].y;
    for (const auto& pt : corners_out) {
        min_x = std::min(min_x, pt.x);
        max_x = std::max(max_x, pt.x);
        min_y = std::min(min_y, pt.y);
        max_y = std::max(max_y, pt.y);
    }

    // Step 4: translation matrix T to shift negative coordinates to (0,0)
    cv::Mat T = cv::Mat::eye(3, 3, CV_64F);
    T.at<double>(0, 2) = -min_x;
    T.at<double>(1, 2) = -min_y;

    // Step 5: H' = T * H
    H_out     = T * H;
    warp_w_out = static_cast<int>(std::ceil(max_x - min_x));
    warp_h_out = static_cast<int>(std::ceil(max_y - min_y));

    return true;
}

// ---------------------------------------------------------------------------
// Internal helper: draw pixel grid over warped image for alignment verification
// ---------------------------------------------------------------------------

static void drawGrid(cv::Mat& img, int step = 50)
{
    for (int x = 0; x < img.cols; x += step) {
        cv::line(img, {x, 0}, {x, img.rows}, cv::Scalar(0, 180, 0), 1);
    }
    for (int y = 0; y < img.rows; y += step) {
        cv::line(img, {0, y}, {img.cols, y}, cv::Scalar(0, 180, 0), 1);
    }
}

// ---------------------------------------------------------------------------
// Mouse callback state for Phase 1.5 (manual corner selection)
// ---------------------------------------------------------------------------

struct MouseState {
    std::vector<cv::Point2f> points;
    cv::Mat display_frame;
};

static void onMouse(int event, int x, int y, int /*flags*/, void* userdata)
{
    auto* state = reinterpret_cast<MouseState*>(userdata);
    if (event == cv::EVENT_LBUTTONDOWN && state->points.size() < 4) {
        state->points.emplace_back(static_cast<float>(x), static_cast<float>(y));
        cv::circle(state->display_frame,
                   {x, y}, 6, cv::Scalar(0, 0, 255), -1);
        cv::putText(state->display_frame,
                    std::to_string(state->points.size()),
                    {x + 8, y - 8},
                    cv::FONT_HERSHEY_SIMPLEX, 0.6,
                    cv::Scalar(0, 255, 255), 1, cv::LINE_AA);
        cv::imshow("Calibration", state->display_frame);
    }
}

// ---------------------------------------------------------------------------
// run_calib_mode
// ---------------------------------------------------------------------------

void run_calib_mode(AppConfig& config)
{
    AppCamera cam;
    if (!cam.open(config.camera)) {
        std::cerr << "[Calib] ERROR: Failed to open camera. Aborting.\n";
        return;
    }

    const int img_w = config.camera.width;
    const int img_h = config.camera.height;

    // ArUco dictionary: DICT_APRILTAG_36h11
    cv::Ptr<cv::aruco::Dictionary> aruco_dict =
        cv::aruco::getPredefinedDictionary(cv::aruco::DICT_APRILTAG_36h11);
    cv::Ptr<cv::aruco::DetectorParameters> aruco_params =
        cv::aruco::DetectorParameters::create();

    cv::Mat frame, warped;
    bool homography_locked = false;

    // Phase 1: Tag detection
    std::cout << "[Calib] PHASE 1: Point camera at ArUco tags 0,1,2,3.\n"
              << "        ENTER to lock homography | 'M' for manual corners | 'q' to quit.\n";

    cv::namedWindow("Calibration", cv::WINDOW_NORMAL);

    while (!homography_locked) {
        if (!cam.read(frame) || frame.empty()) continue;

        std::vector<int> ids;
        std::vector<std::vector<cv::Point2f>> corners;
        cv::aruco::detectMarkers(frame, aruco_dict, corners, ids, aruco_params);

        cv::Mat display = frame.clone();
        cv::aruco::drawDetectedMarkers(display, corners, ids);

        // Check for tags 0, 1, 2, 3
        std::vector<cv::Point2f> src_pts(4), dst_pts(4);
        bool all_found = false;

        if (ids.size() >= 4) {
            // Destination layout: tag 0=TL, 1=TR, 2=BR, 3=BL
            // (adjust to match your physical track layout)
            std::map<int, cv::Point2f> dst_map = {
                {0, {0.0f,                   0.0f}},
                {1, {static_cast<float>(img_w), 0.0f}},
                {2, {static_cast<float>(img_w), static_cast<float>(img_h)}},
                {3, {0.0f,                   static_cast<float>(img_h)}}
            };

            int found = 0;
            for (size_t i = 0; i < ids.size(); ++i) {
                int id = ids[i];
                if (dst_map.count(id)) {
                    // Use the center of the tag
                    cv::Point2f center = {0, 0};
                    for (const auto& c : corners[i]) center += c;
                    center *= 0.25f;

                    src_pts[id] = center;
                    dst_pts[id] = dst_map[id];
                    ++found;
                }
            }
            all_found = (found == 4);
        }

        if (all_found) {
            cv::Mat H_candidate;
            int w, h;
            if (computeAdaptiveHomography(src_pts, dst_pts, img_w, img_h, H_candidate, w, h)) {
                warped = cv::Mat();
                cv::warpPerspective(frame, warped, H_candidate, {w, h});
                cv::Mat warped_grid = warped.clone();
                drawGrid(warped_grid);

                cv::putText(display, "Tags found! ENTER to lock, M=manual, q=quit",
                            {10, 30}, cv::FONT_HERSHEY_SIMPLEX, 0.7,
                            cv::Scalar(0, 255, 0), 2, cv::LINE_AA);
                cv::imshow("Warped Preview", warped_grid);

                int key = cv::waitKey(1);
                if (key == 13 || key == 10) {  // ENTER
                    config.geometry.homography   = H_candidate;
                    config.geometry.warp_width   = w;
                    config.geometry.warp_height  = h;
                    homography_locked = true;
                    std::cout << "[Calib] Homography locked. Warp size: " << w << "x" << h << "\n";
                    break;
                }
                if (key == 'm' || key == 'M') {
                    goto phase_manual;
                }
                if (key == 'q') { cam.release(); return; }
            }
        } else {
            cv::putText(display, "Searching for tags 0,1,2,3...",
                        {10, 30}, cv::FONT_HERSHEY_SIMPLEX, 0.7,
                        cv::Scalar(0, 128, 255), 2, cv::LINE_AA);
        }

        cv::imshow("Calibration", display);
        int key = cv::waitKey(1);
        if (key == 'm' || key == 'M') {
            goto phase_manual;
        }
        if (key == 'q') { cam.release(); return; }
        continue;

        // -------------------------------------------------------------------
        // Phase 1.5: Manual corner fallback
        // -------------------------------------------------------------------
        phase_manual:
        {
            std::cout << "[Calib] PHASE 1.5 (Manual): Click 4 corners in order: TL, TR, BR, BL.\n";

            MouseState mouse_state;
            cam.read(frame);
            mouse_state.display_frame = frame.clone();

            cv::setMouseCallback("Calibration", onMouse, &mouse_state);
            cv::imshow("Calibration", mouse_state.display_frame);

            while (mouse_state.points.size() < 4) {
                int k = cv::waitKey(20);
                if (k == 'q') { cam.release(); return; }
            }
            cv::setMouseCallback("Calibration", nullptr);

            // Destination corners matching click order: TL, TR, BR, BL
            std::vector<cv::Point2f> dst_manual = {
                {0.0f,                   0.0f},
                {static_cast<float>(img_w), 0.0f},
                {static_cast<float>(img_w), static_cast<float>(img_h)},
                {0.0f,                   static_cast<float>(img_h)}
            };

            cv::Mat H_manual;
            int w, h;
            if (computeAdaptiveHomography(mouse_state.points, dst_manual,
                                          img_w, img_h, H_manual, w, h)) {
                cv::warpPerspective(frame, warped, H_manual, {w, h});
                cv::Mat warped_grid = warped.clone();
                drawGrid(warped_grid);
                cv::imshow("Warped Preview", warped_grid);

                std::cout << "[Calib] Manual homography computed. Press ENTER to lock or 'R' to retry.\n";
                while (true) {
                    int k = cv::waitKey(0);
                    if (k == 13 || k == 10) {  // ENTER
                        config.geometry.homography  = H_manual;
                        config.geometry.warp_width  = w;
                        config.geometry.warp_height = h;
                        homography_locked = true;
                        std::cout << "[Calib] Manual homography locked. Warp size: " << w << "x" << h << "\n";
                        break;
                    }
                    if (k == 'r' || k == 'R') break;  // restart outer loop
                    if (k == 'q') { cam.release(); return; }
                }
            }
        }
    }

    cam.release();
    cv::destroyWindow("Calibration");
    if (cv::getWindowProperty("Warped Preview", cv::WND_PROP_VISIBLE) >= 0) {
        cv::destroyWindow("Warped Preview");
    }

    // Rebuild warped image from locked homography
    // (warped may already be set; re-grab a fresh frame to be safe)
    {
        AppCamera cam2;
        if (cam2.open(config.camera)) {
            cv::Mat fresh;
            cam2.read(fresh);
            cam2.release();
            if (!fresh.empty()) {
                cv::warpPerspective(fresh, warped,
                                    config.geometry.homography,
                                    {config.geometry.warp_width,
                                     config.geometry.warp_height});
            }
        }
    }

    // -------------------------------------------------------------------
    // Phase 2: ROI Selection
    // -------------------------------------------------------------------
    std::cout << "[Calib] PHASE 2: Select ROIs on the warped image.\n"
              << "        Drag to select, press ENTER or SPACE to confirm each one.\n";

    float inv_w = 1.0f / static_cast<float>(config.geometry.warp_width);
    float inv_h = 1.0f / static_cast<float>(config.geometry.warp_height);

    // Red line ROI
    {
        cv::Rect roi_px = cv::selectROI("Select Red Line ROI", warped, false, false);
        cv::destroyWindow("Select Red Line ROI");

        config.roi.red_line_roi = cv::Rect2f(
            roi_px.x      * inv_w,
            roi_px.y      * inv_h,
            roi_px.width  * inv_w,
            roi_px.height * inv_h
        );
        std::cout << "[Calib] Red line ROI (normalized): "
                  << config.roi.red_line_roi << "\n";
    }

    // YOLO ROI
    {
        cv::Rect roi_px = cv::selectROI("Select YOLO ROI", warped, false, false);
        cv::destroyWindow("Select YOLO ROI");

        config.roi.yolo_roi = cv::Rect2f(
            roi_px.x      * inv_w,
            roi_px.y      * inv_h,
            roi_px.width  * inv_w,
            roi_px.height * inv_h
        );
        std::cout << "[Calib] YOLO ROI (normalized): "
                  << config.roi.yolo_roi << "\n";
    }

    // -------------------------------------------------------------------
    // Phase 3: Live HSV Tuning
    // -------------------------------------------------------------------
    std::cout << "[Calib] PHASE 3: Tune HSV thresholds for the red line.\n"
              << "        Adjust trackbars until the finish line is bright white.\n"
              << "        Press ENTER to save and exit.\n";

    const std::string tuner_win = "HSV Tuner";
    cv::namedWindow(tuner_win, cv::WINDOW_NORMAL);

    // Initial values from config (supports re-entry)
    int h_min = config.hsv.h_min, s_min = config.hsv.s_min, v_min = config.hsv.v_min;
    int h_max = config.hsv.h_max, s_max = config.hsv.s_max, v_max = config.hsv.v_max;

    cv::createTrackbar("H min", tuner_win, &h_min, 179);
    cv::createTrackbar("H max", tuner_win, &h_max, 179);
    cv::createTrackbar("S min", tuner_win, &s_min, 255);
    cv::createTrackbar("S max", tuner_win, &s_max, 255);
    cv::createTrackbar("V min", tuner_win, &v_min, 255);
    cv::createTrackbar("V max", tuner_win, &v_max, 255);

    // Pre-crop the red line ROI from the frozen warped image
    int rl_x = static_cast<int>(config.roi.red_line_roi.x      * config.geometry.warp_width);
    int rl_y = static_cast<int>(config.roi.red_line_roi.y      * config.geometry.warp_height);
    int rl_w = static_cast<int>(config.roi.red_line_roi.width  * config.geometry.warp_width);
    int rl_h = static_cast<int>(config.roi.red_line_roi.height * config.geometry.warp_height);

    // Clamp to image bounds
    rl_x = std::max(0, std::min(rl_x, config.geometry.warp_width  - 1));
    rl_y = std::max(0, std::min(rl_y, config.geometry.warp_height - 1));
    rl_w = std::max(1, std::min(rl_w, config.geometry.warp_width  - rl_x));
    rl_h = std::max(1, std::min(rl_h, config.geometry.warp_height - rl_y));

    cv::Mat rl_crop = warped(cv::Rect(rl_x, rl_y, rl_w, rl_h)).clone();
    cv::Mat rl_hsv, mask;

    while (true) {
        cv::cvtColor(rl_crop, rl_hsv, cv::COLOR_BGR2HSV);
        cv::inRange(rl_hsv,
                    cv::Scalar(h_min, s_min, v_min),
                    cv::Scalar(h_max, s_max, v_max),
                    mask);

        cv::imshow(tuner_win, mask);

        int key = cv::waitKey(30);
        if (key == 13 || key == 10) {  // ENTER
            break;
        }
        if (key == 'q') {
            std::cout << "[Calib] HSV tuning cancelled.\n";
            cv::destroyAllWindows();
            cam.release();
            return;
        }
    }

    // Save trackbar values back into config
    config.hsv.h_min = h_min;
    config.hsv.s_min = s_min;
    config.hsv.v_min = v_min;
    config.hsv.h_max = h_max;
    config.hsv.s_max = s_max;
    config.hsv.v_max = v_max;

    cv::destroyAllWindows();

    // Persist everything to disk
    if (config.save("config.yaml")) {
        std::cout << "[Calib] Calibration complete. config.yaml written.\n";
    } else {
        std::cerr << "[Calib] ERROR: Failed to write config.yaml.\n";
    }
}
