#include "app_config.hpp"
#include "app_test.hpp"
#include "app_calib.hpp"
#include "app_deploy.hpp"

#include <iostream>
#include <opencv2/core.hpp>

/**
 * @file app_main.cpp
 * @brief The router — CLI parsing, config loading, and strict mode dispatch.
 *
 * Rules enforced in this file:
 *  - No OpenCV camera calls.
 *  - No business logic.
 *  - No image processing.
 *  - Config is loaded from disk first; CLI flags can override individual fields.
 *  - Exactly one mode is dispatched per run.
 *
 * Usage:
 *   ./vision_pipeline --test    [--no-ui] [--config=<path>]
 *   ./vision_pipeline --calib   [--config=<path>]
 *   ./vision_pipeline --deploy  [--no-ui] [--config=<path>]
 */

int main(int argc, char** argv)
{
    // -----------------------------------------------------------------------
    // CLI definition
    // -----------------------------------------------------------------------
    const cv::String keys =
        "{ help    h  |       | Print this help message.                          }"
        "{ config  c  | config.yaml | Path to the YAML configuration file.        }"
        "{ test    t  | false | Run hardware profiler (camera FPS / latency).     }"
        "{ calib      | false | Run interactive spatial calibration wizard.        }"
        "{ deploy  d  | false | Run high-performance inference pipeline.           }"
        "{ no-ui      | false | Suppress all GUI windows (headless/SSH mode).     }"
        // Camera overrides (optional — loaded from config.yaml by default)
        "{ camera-id  |    -1 | Override camera index from config.               }"
        "{ width      |    -1 | Override capture width from config.              }"
        "{ height     |    -1 | Override capture height from config.             }"
        "{ fps        |    -1 | Override capture FPS from config.                }";

    cv::CommandLineParser parser(argc, argv, keys);
    parser.about("Intelligence Racing Vision Pipeline v1.0");

    if (parser.has("help")) {
        parser.printMessage();
        return 0;
    }

    // -----------------------------------------------------------------------
    // Load base configuration from disk
    // -----------------------------------------------------------------------
    const std::string config_path = parser.get<std::string>("config");
    AppConfig config;

    // A missing config file is not fatal for --calib (it creates one from scratch).
    // For --test and --deploy it is a hard requirement.
    bool config_loaded = config.load(config_path);

    // -----------------------------------------------------------------------
    // Apply CLI overrides (only when explicitly provided)
    // -----------------------------------------------------------------------
    {
        int cam_id = parser.get<int>("camera-id");
        int width  = parser.get<int>("width");
        int height = parser.get<int>("height");
        int fps    = parser.get<int>("fps");

        if (cam_id >= 0) config.camera.camera_id = cam_id;
        if (width  >  0) config.camera.width      = width;
        if (height >  0) config.camera.height     = height;
        if (fps    >  0) config.camera.fps         = fps;
    }

    const bool no_ui = parser.get<bool>("no-ui");

    // -----------------------------------------------------------------------
    // Mode dispatch — strict if/else, no fallthrough
    // -----------------------------------------------------------------------
    if (parser.get<bool>("test")) {

        run_test_mode(config, no_ui);

    } else if (parser.get<bool>("calib")) {

        run_calib_mode(config);

    } else if (parser.get<bool>("deploy")) {

        if (!config_loaded) {
            std::cerr << "[Main] ERROR: --deploy requires a valid config.yaml. "
                      << "Run --calib first.\n";
            return 1;
        }
        run_deploy_mode(config, no_ui);

    } else {

        std::cerr << "[Main] No mode specified. Use --test, --calib, or --deploy.\n";
        parser.printMessage();
        return 1;

    }

    return 0;
}
