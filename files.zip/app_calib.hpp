#pragma once

#include "app_config.hpp"

/**
 * @file app_calib.hpp
 * @brief Spatial calibration engine — interactive 4-phase calibration wizard.
 *
 * Phase 1   — ArUco tag detection + adaptive homography computation.
 * Phase 1.5 — Manual corner fallback (user clicks 4 points with mouse).
 * Phase 2   — ROI selection (red line + YOLO crop).
 * Phase 3   — Live HSV threshold tuning with trackbars.
 *
 * On completion the config is written to disk via AppConfig::save().
 */

/**
 * @brief Run the interactive calibration wizard.
 *
 * Mutates config in-place and saves config.yaml on successful completion.
 *
 * @param config  AppConfig (will be modified with homography, ROIs, HSV values).
 */
void run_calib_mode(AppConfig& config);
