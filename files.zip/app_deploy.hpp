#pragma once

#include "app_config.hpp"

/**
 * @file app_deploy.hpp
 * @brief High-performance runtime mode targeting sub-2ms frame processing.
 *
 * Key architectural decisions enforced here:
 *  - cv::warpPerspective is NEVER called in the main loop.
 *  - Two targeted inverse remap maps are pre-computed at startup from the
 *    inverse homography: one for the red-line ROI, one for the YOLO ROI.
 *  - Maps are stored in CV_16SC2 format for ARM NEON acceleration.
 *  - The YOLO gate is only triggered when the red-pixel count exceeds a
 *    threshold, saving ~80% of YOLO inference calls during a race.
 */

/**
 * @brief Run the high-performance inference pipeline.
 *
 * @param config  Fully calibrated AppConfig (homography, ROIs, HSV values).
 * @param no_ui   If true, suppress all cv::imshow calls for maximum throughput.
 */
void run_deploy_mode(const AppConfig& config, bool no_ui);
