#pragma once

#include "app_config.hpp"

#include <opencv2/videoio.hpp>

/**
 * @file app_camera.hpp
 * @brief Hardware wrapper around cv::VideoCapture for V4L2 cameras.
 *
 * Enforces:
 *  - V4L2 backend (no GStreamer or auto-detected backend)
 *  - Buffer size of 1 to eliminate frame lag
 *  - Auto-exposure disabled with a fixed exposure value
 *
 * All camera access in the project must go through this class.
 */

class AppCamera {
public:
    AppCamera() = default;
    ~AppCamera();

    /**
     * @brief Open the camera using the V4L2 backend and apply all settings.
     * @param cfg  CameraConfig from AppConfig (id, width, height, fps).
     * @return true if the camera was successfully opened, false otherwise.
     */
    bool open(const CameraConfig& cfg);

    /**
     * @brief Grab the latest frame from the camera.
     *
     * With buffer size 1 this always returns the most recent frame from the
     * sensor, not a queued/stale one.
     *
     * @param frame  Output frame (BGR, camera native resolution).
     * @return true if a frame was grabbed, false on end-of-stream or error.
     */
    bool read(cv::Mat& frame);

    /**
     * @brief Release the underlying cv::VideoCapture.
     */
    void release();

    /**
     * @return true if the underlying capture is open.
     */
    bool isOpened() const;

private:
    cv::VideoCapture cap_;
};
