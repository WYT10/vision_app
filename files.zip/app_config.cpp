#include "app_config.hpp"

#include <iostream>
#include <opencv2/core.hpp>

/**
 * @file app_config.cpp
 * @brief Implementation of AppConfig::load() and AppConfig::save().
 *
 * All serialization uses cv::FileStorage so that the 3x3 cv::Mat homography is
 * written and read using OpenCV's native !!opencv-matrix YAML format.
 * No hand-rolled string parsing is used anywhere in this file.
 */

// ---------------------------------------------------------------------------
// load
// ---------------------------------------------------------------------------

bool AppConfig::load(const std::string& path)
{
    cv::FileStorage fs(path, cv::FileStorage::READ);
    if (!fs.isOpened()) {
        std::cerr << "[AppConfig] ERROR: Cannot open '" << path << "' for reading.\n";
        return false;
    }

    // --- Camera ---
    cv::FileNode cam = fs["camera"];
    if (!cam.empty()) {
        cam["camera_id"] >> camera.camera_id;
        cam["width"]     >> camera.width;
        cam["height"]    >> camera.height;
        cam["fps"]       >> camera.fps;
    }

    // --- Geometry ---
    cv::FileNode geo = fs["geometry"];
    if (!geo.empty()) {
        geo["homography"]   >> geometry.homography;
        geo["warp_width"]   >> geometry.warp_width;
        geo["warp_height"]  >> geometry.warp_height;
    }

    // --- ROIs (stored as float vectors [x, y, w, h]) ---
    cv::FileNode roi_node = fs["roi"];
    if (!roi_node.empty()) {
        std::vector<float> rl, yo;
        roi_node["red_line_roi"] >> rl;
        roi_node["yolo_roi"]     >> yo;

        if (rl.size() == 4) {
            roi.red_line_roi = cv::Rect2f(rl[0], rl[1], rl[2], rl[3]);
        }
        if (yo.size() == 4) {
            roi.yolo_roi = cv::Rect2f(yo[0], yo[1], yo[2], yo[3]);
        }
    }

    // --- HSV thresholds ---
    cv::FileNode hsv_node = fs["hsv"];
    if (!hsv_node.empty()) {
        hsv_node["h_min"] >> hsv.h_min;
        hsv_node["s_min"] >> hsv.s_min;
        hsv_node["v_min"] >> hsv.v_min;
        hsv_node["h_max"] >> hsv.h_max;
        hsv_node["s_max"] >> hsv.s_max;
        hsv_node["v_max"] >> hsv.v_max;
    }

    fs.release();
    std::cout << "[AppConfig] Loaded config from '" << path << "'.\n";
    return true;
}

// ---------------------------------------------------------------------------
// save
// ---------------------------------------------------------------------------

bool AppConfig::save(const std::string& path) const
{
    cv::FileStorage fs(path, cv::FileStorage::WRITE);
    if (!fs.isOpened()) {
        std::cerr << "[AppConfig] ERROR: Cannot open '" << path << "' for writing.\n";
        return false;
    }

    // --- Camera ---
    fs << "camera" << "{";
    fs << "camera_id" << camera.camera_id;
    fs << "width"     << camera.width;
    fs << "height"    << camera.height;
    fs << "fps"       << camera.fps;
    fs << "}";

    // --- Geometry ---
    // cv::Mat serializes as !!opencv-matrix automatically via cv::FileStorage
    fs << "geometry" << "{";
    fs << "homography"  << geometry.homography;
    fs << "warp_width"  << geometry.warp_width;
    fs << "warp_height" << geometry.warp_height;
    fs << "}";

    // --- ROIs ---
    fs << "roi" << "{";

    fs << "red_line_roi" << "[";
    fs << roi.red_line_roi.x << roi.red_line_roi.y
       << roi.red_line_roi.width << roi.red_line_roi.height;
    fs << "]";

    fs << "yolo_roi" << "[";
    fs << roi.yolo_roi.x << roi.yolo_roi.y
       << roi.yolo_roi.width << roi.yolo_roi.height;
    fs << "]";

    fs << "}";

    // --- HSV ---
    fs << "hsv" << "{";
    fs << "h_min" << hsv.h_min;
    fs << "s_min" << hsv.s_min;
    fs << "v_min" << hsv.v_min;
    fs << "h_max" << hsv.h_max;
    fs << "s_max" << hsv.s_max;
    fs << "v_max" << hsv.v_max;
    fs << "}";

    fs.release();
    std::cout << "[AppConfig] Saved config to '" << path << "'.\n";
    return true;
}
