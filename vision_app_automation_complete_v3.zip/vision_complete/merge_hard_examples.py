#!/usr/bin/env python3
from pathlib import Path
import runpy
runpy.run_path(str((Path(__file__).resolve().parent / "training_tools/merge_hard_examples.py").resolve()), run_name="__main__")
